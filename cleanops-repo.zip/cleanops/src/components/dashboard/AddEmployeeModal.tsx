'use client'

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Modal, Button, Input } from '@/components/ui'

const schema = z.object({
  full_name: z.string().min(2, 'Name must be at least 2 characters'),
  phone:     z.string().min(7, 'Enter a valid phone number').optional().or(z.literal('')),
  email:     z.string().email().optional().or(z.literal('')),
  notes:     z.string().optional(),
})
type FormData = z.infer<typeof schema>

interface AddEmployeeModalProps {
  open:     boolean
  onClose:  () => void
  onAdded:  () => void
}

export function AddEmployeeModal({ open, onClose, onAdded }: AddEmployeeModalProps) {
  const [serverError, setServerError] = useState('')
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
  })

  async function onSubmit(data: FormData) {
    setServerError('')
    const res = await fetch('/api/employees', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    })
    if (!res.ok) {
      const err = await res.json()
      setServerError(err.error ?? 'Something went wrong')
      return
    }
    reset()
    onAdded()
    onClose()
  }

  return (
    <Modal open={open} onClose={onClose} title="Add New Cleaner">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <Input
          id="full_name"
          label="Full Name *"
          placeholder="Maria Garcia"
          error={errors.full_name?.message}
          {...register('full_name')}
        />
        <Input
          id="phone"
          label="Phone Number"
          placeholder="+1 555 000 0000"
          type="tel"
          hint="Used to send WhatsApp invite"
          error={errors.phone?.message}
          {...register('phone')}
        />
        <Input
          id="email"
          label="Email (optional)"
          placeholder="maria@example.com"
          type="email"
          error={errors.email?.message}
          {...register('email')}
        />
        <div className="space-y-1">
          <label htmlFor="notes" className="block text-sm font-medium text-slate-700">
            Notes (optional)
          </label>
          <textarea
            id="notes"
            rows={2}
            placeholder="Part-time, weekends only..."
            className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-200 focus:border-teal-400"
            {...register('notes')}
          />
        </div>

        {serverError && (
          <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{serverError}</p>
        )}

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="secondary" className="flex-1" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" className="flex-1" loading={isSubmitting}>
            Add Cleaner
          </Button>
        </div>
      </form>
    </Modal>
  )
}
