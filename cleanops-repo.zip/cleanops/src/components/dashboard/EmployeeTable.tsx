'use client'

import { Badge } from '@/components/ui'
import { READINESS_CONFIG } from '@/lib/utils'
import type { EmployeeWithReadiness, ReadinessStatus } from '@/lib/types'
import { MessageCircle, Eye, RefreshCw, ToggleLeft, ToggleRight } from 'lucide-react'

interface EmployeeTableProps {
  employees: EmployeeWithReadiness[]
  onView:        (id: string) => void
  onWhatsApp:    (id: string, token: string, name: string) => void
  onResend:      (id: string, name: string) => void
  onToggleAvail: (id: string, current: boolean) => void
}

export function EmployeeTable({
  employees,
  onView,
  onWhatsApp,
  onResend,
  onToggleAvail,
}: EmployeeTableProps) {
  if (employees.length === 0) {
    return (
      <div className="text-center py-12 text-slate-400">
        <p className="text-lg">No employees found.</p>
      </div>
    )
  }

  return (
    <div className="overflow-x-auto rounded-xl border border-slate-200">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-slate-50 border-b border-slate-200">
            <th className="text-left px-4 py-3 font-semibold text-slate-600">Name</th>
            <th className="text-left px-4 py-3 font-semibold text-slate-600">Phone</th>
            <th className="text-left px-4 py-3 font-semibold text-slate-600">Status</th>
            <th className="text-left px-4 py-3 font-semibold text-slate-600">Progress</th>
            <th className="text-left px-4 py-3 font-semibold text-slate-600">Available</th>
            <th className="text-right px-4 py-3 font-semibold text-slate-600">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {employees.map((emp) => {
            const cfg = READINESS_CONFIG[emp.readiness_status as ReadinessStatus]
            const pct = emp.steps_total > 0
              ? Math.round((emp.steps_approved / emp.steps_total) * 100)
              : 0

            return (
              <tr
                key={emp.id}
                className="hover:bg-slate-50 transition-colors cursor-pointer"
                onClick={() => onView(emp.id)}
              >
                <td className="px-4 py-3 font-medium text-slate-900">{emp.full_name}</td>
                <td className="px-4 py-3 text-slate-500">{emp.phone ?? '—'}</td>
                <td className="px-4 py-3">
                  <Badge className={cfg.className} dot dotColor={cfg.dot}>
                    {cfg.label}
                  </Badge>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-teal-500 rounded-full transition-all"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-400">
                      {emp.steps_approved}/{emp.steps_total}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={(e) => { e.stopPropagation(); onToggleAvail(emp.id, emp.is_available) }}
                    className="text-slate-400 hover:text-teal-600 transition-colors"
                    title={emp.is_available ? 'Mark unavailable' : 'Mark available'}
                  >
                    {emp.is_available
                      ? <ToggleRight className="w-5 h-5 text-teal-500" />
                      : <ToggleLeft className="w-5 h-5" />
                    }
                  </button>
                </td>
                <td className="px-4 py-3">
                  <div
                    className="flex items-center justify-end gap-1"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      onClick={() => onView(emp.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 hover:bg-teal-50 transition-colors"
                      title="View details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onWhatsApp(emp.id, emp.onboard_token, emp.full_name)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-green-600 hover:bg-green-50 transition-colors"
                      title="Send WhatsApp invite"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onResend(emp.id, emp.full_name)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                      title="Resend link"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
