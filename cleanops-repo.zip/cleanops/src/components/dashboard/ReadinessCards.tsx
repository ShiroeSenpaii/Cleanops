'use client'

import { READINESS_CONFIG } from '@/lib/utils'
import type { ReadinessStatus } from '@/lib/types'

interface ReadinessCardsProps {
  counts: Record<ReadinessStatus, number>
  total: number
  activeFilter: ReadinessStatus | null
  onFilter: (status: ReadinessStatus | null) => void
}

export function ReadinessCards({ counts, total, activeFilter, onFilter }: ReadinessCardsProps) {
  const statuses: ReadinessStatus[] = ['READY', 'NEEDS_REVIEW', 'IN_PROGRESS', 'BLOCKED']

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {statuses.map((status) => {
        const config = READINESS_CONFIG[status]
        const count = counts[status] ?? 0
        const isActive = activeFilter === status
        const pct = total > 0 ? Math.round((count / total) * 100) : 0

        return (
          <button
            key={status}
            onClick={() => onFilter(isActive ? null : status)}
            className={`
              text-left p-4 rounded-xl border-2 transition-all
              ${isActive
                ? 'border-teal-500 bg-teal-50 shadow-md'
                : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'
              }
            `}
          >
            <div className="flex items-center gap-2 mb-2">
              <span className={`w-2.5 h-2.5 rounded-full ${config.dot}`} />
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wide">
                {config.label}
              </span>
            </div>
            <div className="text-3xl font-bold text-slate-900">{count}</div>
            <div className="text-xs text-slate-400 mt-0.5">{pct}% of team</div>
          </button>
        )
      })}
    </div>
  )
}
