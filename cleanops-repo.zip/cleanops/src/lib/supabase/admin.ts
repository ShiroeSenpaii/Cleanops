import { createClient } from '@supabase/supabase-js'

// Service role client — bypasses RLS.
// ONLY use in API routes, never in client-side code.
// Used for: employee portal (token-based, no auth.uid()),
//           cron reminders, bulk operations.

export function createAdminClient() {
  if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('SUPABASE_SERVICE_ROLE_KEY is not set')
  }
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    }
  )
}
