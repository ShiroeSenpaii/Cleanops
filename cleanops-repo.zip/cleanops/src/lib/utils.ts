import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'
import type { ReadinessStatus, StepStatus, Language } from './types'

// ── Tailwind class helper ─────────────────────────────────
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ── WhatsApp link generation ──────────────────────────────
export function generateWhatsAppInvite(
  employeeName: string,
  companyName: string,
  token: string
): string {
  const url = `${process.env.NEXT_PUBLIC_APP_URL}/onboard/${token}`
  const msg = [
    `Hi ${employeeName}! 👋`,
    ``,
    `Welcome to ${companyName}. Please complete your onboarding here:`,
    ``,
    url,
    ``,
    `This link is just for you. Takes about 10 minutes. Let me know if you have questions!`,
  ].join('\n')
  return `https://wa.me/?text=${encodeURIComponent(msg)}`
}

export function generateWhatsAppReminder(
  employeeName: string,
  stepTitle: string,
  token: string
): string {
  const url = `${process.env.NEXT_PUBLIC_APP_URL}/onboard/${token}`
  const msg = [
    `Hi ${employeeName} 👋`,
    ``,
    `Quick reminder — you still need to complete: *${stepTitle}*`,
    ``,
    `Continue here: ${url}`,
  ].join('\n')
  return `https://wa.me/?text=${encodeURIComponent(msg)}`
}

// ── Readiness badge config ────────────────────────────────
export const READINESS_CONFIG: Record<
  ReadinessStatus,
  { label: string; className: string; dot: string }
> = {
  READY: {
    label: 'Ready',
    className: 'bg-green-100 text-green-800',
    dot: 'bg-green-500',
  },
  IN_PROGRESS: {
    label: 'In Progress',
    className: 'bg-blue-100 text-blue-800',
    dot: 'bg-blue-500',
  },
  NEEDS_REVIEW: {
    label: 'Needs Review',
    className: 'bg-amber-100 text-amber-800',
    dot: 'bg-amber-500',
  },
  BLOCKED: {
    label: 'Blocked',
    className: 'bg-red-100 text-red-800',
    dot: 'bg-red-500',
  },
}

// ── Step status config ────────────────────────────────────
export const STEP_STATUS_CONFIG: Record<
  StepStatus,
  { label: string; className: string }
> = {
  NOT_STARTED:  { label: 'Not Started',  className: 'bg-gray-100 text-gray-600' },
  SUBMITTED:    { label: 'Submitted',    className: 'bg-blue-100 text-blue-700' },
  NEEDS_REVIEW: { label: 'Needs Review', className: 'bg-amber-100 text-amber-700' },
  APPROVED:     { label: 'Approved',     className: 'bg-green-100 text-green-700' },
  REJECTED:     { label: 'Rejected',     className: 'bg-red-100 text-red-700' },
}

// ── Accepted file types ───────────────────────────────────
export const ACCEPTED_MIME_TYPES = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/heic',
  'image/heif',
  'application/pdf',
]

export const ACCEPTED_EXTENSIONS = '.jpg,.jpeg,.png,.heic,.heif,.pdf'
export const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024 // 10MB

// ── i18n strings for employee portal ─────────────────────
export const PORTAL_STRINGS: Record<Language, Record<string, string>> = {
  en: {
    welcome: 'Welcome',
    nextStep: 'YOUR NEXT STEP',
    allSteps: 'All Steps',
    upload: 'Upload Document',
    acknowledge: 'I Confirm',
    submitted: 'Submitted — waiting for review',
    needsReview: 'Under review',
    approved: 'Approved ✓',
    rejected: 'Rejected — please re-upload',
    reUpload: 'Re-upload',
    uploading: 'Uploading…',
    offline: "You're offline. Your upload will send when you reconnect.",
    progress: 'Step {current} of {total} — about {minutes} minutes left',
    done: "You're all set! 🎉",
    doneSubtitle: 'Your onboarding is complete. We\'ll be in touch.',
    chatOwner: 'Questions? Chat with your manager',
    tapToPhoto: 'Tap to take a photo or upload a file',
    holdSteady: 'Hold steady — make sure all 4 corners are visible',
    fileTooLarge: 'File is too large. Maximum size is 10MB.',
    fileInvalidType: 'Invalid file type. Please upload a photo or PDF.',
  },
  es: {
    welcome: 'Bienvenido',
    nextStep: 'TU PRÓXIMO PASO',
    allSteps: 'Todos los pasos',
    upload: 'Subir Documento',
    acknowledge: 'Confirmo',
    submitted: 'Enviado — esperando revisión',
    needsReview: 'En revisión',
    approved: 'Aprobado ✓',
    rejected: 'Rechazado — por favor vuelve a subir',
    reUpload: 'Volver a subir',
    uploading: 'Subiendo…',
    offline: 'Estás sin conexión. Tu archivo se enviará cuando vuelvas a conectarte.',
    progress: 'Paso {current} de {total} — quedan unos {minutes} minutos',
    done: '¡Todo listo! 🎉',
    doneSubtitle: 'Tu proceso de incorporación está completo. Nos pondremos en contacto.',
    chatOwner: '¿Preguntas? Habla con tu gerente',
    tapToPhoto: 'Toca para tomar una foto o subir un archivo',
    holdSteady: 'Mantén firme — asegúrate de que los 4 rincones sean visibles',
    fileTooLarge: 'El archivo es demasiado grande. El tamaño máximo es 10MB.',
    fileInvalidType: 'Tipo de archivo no válido. Por favor sube una foto o PDF.',
  },
}

// ── Estimated minutes per step type ──────────────────────
export const STEP_MINUTES: Record<string, number> = {
  sign_contract:      3,
  upload_photo_id:    1,
  fill_w9:            4,
  direct_deposit:     2,
  coi_acknowledgment: 1,
  background_consent: 1,
}

export function estimateMinutesRemaining(
  steps: { step_key: string; status: string }[]
): number {
  return steps
    .filter(s => s.status !== 'APPROVED')
    .reduce((acc, s) => acc + (STEP_MINUTES[s.step_key] ?? 2), 0)
}

// ── Slug generation ───────────────────────────────────────
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 50)
}

// ── Format phone for WhatsApp ─────────────────────────────
export function formatPhoneForWhatsApp(phone: string): string {
  return phone.replace(/\D/g, '')
}

// ── Supabase Storage path builder ────────────────────────
export function buildStoragePath(
  companyId: string,
  employeeId: string,
  stepKey: string,
  fileName: string
): string {
  const timestamp = Date.now()
  const safe = fileName.replace(/[^a-zA-Z0-9._-]/g, '_')
  return `${companyId}/${employeeId}/${stepKey}/${timestamp}_${safe}`
}
