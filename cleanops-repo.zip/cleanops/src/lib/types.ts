// ============================================================
// CleanOps — Core Types
// ============================================================

export type StepStatus =
  | 'NOT_STARTED'
  | 'SUBMITTED'
  | 'NEEDS_REVIEW'
  | 'APPROVED'
  | 'REJECTED'

export type ReadinessStatus =
  | 'READY'
  | 'IN_PROGRESS'
  | 'NEEDS_REVIEW'
  | 'BLOCKED'

export type StepType = 'document_upload' | 'acknowledgment'

export type Language = 'en' | 'es'

export type MessageChannel = 'whatsapp' | 'sms' | 'email'

export type MessageType =
  | 'onboarding_invite'
  | 'reminder'
  | 'approved'
  | 'rejected'

// ── DB row shapes ────────────────────────────────────────

export interface Company {
  id: string
  name: string
  slug: string
  phone: string | null
  logo_url: string | null
  created_at: string
  updated_at: string
}

export interface Owner {
  id: string
  user_id: string
  company_id: string
  full_name: string | null
  email: string
  created_at: string
  updated_at: string
}

export interface Employee {
  id: string
  company_id: string
  full_name: string
  phone: string | null
  email: string | null
  preferred_language: Language
  is_available: boolean
  onboard_token: string
  token_expires_at: string | null
  is_active: boolean
  notes: string | null
  created_at: string
  updated_at: string
}

export interface OnboardingTemplate {
  id: string
  company_id: string
  name: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface TemplateStep {
  id: string
  template_id: string
  step_key: string
  title: string
  title_es: string
  description: string
  description_es: string
  video_gif_url: string | null
  step_type: StepType
  is_required: boolean
  sort_order: number
  created_at: string
}

export interface EmployeeOnboarding {
  id: string
  employee_id: string
  template_id: string
  company_id: string
  started_at: string | null
  completed_at: string | null
  created_at: string
  updated_at: string
}

export interface StepSubmission {
  id: string
  onboarding_id: string
  template_step_id: string
  company_id: string
  employee_id: string
  status: StepStatus
  file_path: string | null
  file_name: string | null
  file_size_bytes: number | null
  mime_type: string | null
  notes_from_owner: string | null
  submitted_at: string | null
  reviewed_at: string | null
  reviewed_by: string | null
  reminder_sent_at: string | null
  reminder_count: number
  created_at: string
  updated_at: string
}

export interface MessageLog {
  id: string
  company_id: string
  employee_id: string
  owner_id: string | null
  channel: MessageChannel
  message_type: MessageType
  link_url: string
  was_opened: boolean
  opened_at: string | null
  created_at: string
}

// ── Composite shapes used in API responses ───────────────

export interface EmployeeWithReadiness extends Employee {
  readiness_status: ReadinessStatus
  steps_approved: number
  steps_total: number
  onboarding_id: string
}

export interface StepWithSubmission extends TemplateStep {
  submission: StepSubmission | null
}

export interface OnboardPortalData {
  employee: Pick<Employee, 'id' | 'full_name' | 'preferred_language'>
  company: Pick<Company, 'name' | 'phone'>
  steps: StepWithSubmission[]
  next_step_key: string | null
  readiness_status: ReadinessStatus
  onboarding_id: string
}

// ── API request bodies ───────────────────────────────────

export interface CreateEmployeeBody {
  full_name: string
  phone?: string
  email?: string
  notes?: string
}

export interface ReviewSubmissionBody {
  action: 'APPROVE' | 'REJECT'
  notes?: string
}

export interface UploadUrlBody {
  step_key: string
  file_name: string
  mime_type: string
  file_size: number
}

export interface SubmitStepBody {
  step_key: string
  file_path: string
  file_name: string
  file_size_bytes: number
  mime_type: string
}

export interface AcknowledgeStepBody {
  step_key: string
}

export interface BulkInviteRow {
  full_name: string
  phone: string
  email?: string
  notes?: string
}
