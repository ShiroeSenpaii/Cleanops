import type { SupabaseClient } from '@supabase/supabase-js'

// Called from the signup API route after the owner record is created.
// Seeds the default onboarding template and all 6 steps for a new company.

export async function seedCompanyTemplate(
  supabase: SupabaseClient,
  companyId: string
): Promise<{ templateId: string }> {
  // 1. Create the template
  const { data: template, error: tErr } = await supabase
    .from('onboarding_templates')
    .insert({ company_id: companyId, name: 'Standard Onboarding' })
    .select('id')
    .single()

  if (tErr || !template) throw new Error(`Template seed failed: ${tErr?.message}`)

  // 2. Load step definitions from the reference table
  const { data: defs, error: dErr } = await supabase
    .from('step_definitions')
    .select('*')
    .order('sort_order')

  if (dErr || !defs) throw new Error(`Step definitions load failed: ${dErr?.message}`)

  // 3. Insert steps for this template
  const steps = defs.map((d) => ({
    template_id:    template.id,
    step_key:       d.step_key,
    title:          d.title,
    title_es:       d.title_es,
    description:    d.description,
    description_es: d.description_es,
    step_type:      d.step_type,
    is_required:    true,
    sort_order:     d.sort_order,
  }))

  const { error: sErr } = await supabase.from('template_steps').insert(steps)
  if (sErr) throw new Error(`Steps seed failed: ${sErr.message}`)

  return { templateId: template.id }
}

// Seed step_submissions for a newly created employee.
// Creates one NOT_STARTED row per required step.

export async function seedEmployeeSubmissions(
  supabase: SupabaseClient,
  opts: {
    employeeId: string
    onboardingId: string
    companyId: string
    templateId: string
  }
): Promise<void> {
  const { data: steps, error: stErr } = await supabase
    .from('template_steps')
    .select('id')
    .eq('template_id', opts.templateId)
    .order('sort_order')

  if (stErr || !steps) throw new Error(`Steps fetch failed: ${stErr?.message}`)

  const submissions = steps.map((s) => ({
    onboarding_id:    opts.onboardingId,
    template_step_id: s.id,
    company_id:       opts.companyId,
    employee_id:      opts.employeeId,
    status:           'NOT_STARTED',
  }))

  const { error } = await supabase.from('step_submissions').insert(submissions)
  if (error) throw new Error(`Submissions seed failed: ${error.message}`)
}
