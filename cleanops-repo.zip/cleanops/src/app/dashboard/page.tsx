'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { ReadinessCards } from '@/components/dashboard/ReadinessCards'
import { EmployeeTable } from '@/components/dashboard/EmployeeTable'
import { AddEmployeeModal } from '@/components/dashboard/AddEmployeeModal'
import { Button, Spinner, EmptyState } from '@/components/ui'
import { generateWhatsAppInvite } from '@/lib/utils'
import type { EmployeeWithReadiness, ReadinessStatus } from '@/lib/types'
import { Plus, LogOut, Users, Filter } from 'lucide-react'

export default function DashboardPage() {
  const router = useRouter()
  const [employees, setEmployees] = useState<EmployeeWithReadiness[]>([])
  const [overview, setOverview] = useState({ READY: 0, IN_PROGRESS: 0, NEEDS_REVIEW: 0, BLOCKED: 0, total: 0 })
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [filter, setFilter] = useState<ReadinessStatus | null>(null)
  const [availableOnly, setAvailableOnly] = useState(false)
  const [copiedId, setCopiedId] = useState<string | null>(null)

  const fetchData = useCallback(async () => {
    setLoading(true)
    const params = new URLSearchParams()
    if (availableOnly) params.set('available', 'true')

    const [empRes, ovRes] = await Promise.all([
      fetch(`/api/employees?${params}`),
      fetch('/api/dashboard/overview'),
    ])

    if (empRes.ok) {
      const data = await empRes.json()
      setEmployees(data.employees)
    }
    if (ovRes.ok) {
      setOverview(await ovRes.json())
    }
    setLoading(false)
  }, [availableOnly])

  useEffect(() => { fetchData() }, [fetchData])

  const filtered = filter
    ? employees.filter(e => e.readiness_status === filter)
    : employees

  async function handleWhatsApp(id: string, token: string, name: string) {
    // Fetch company name for message
    const res = await fetch(`/api/employees/${id}/whatsapp-link`)
    if (res.ok) {
      const data = await res.json()
      window.open(data.whatsapp_url, '_blank')
    }
  }

  async function handleResend(id: string, name: string) {
    if (!confirm(`Regenerate and resend the magic link for ${name}? The old link will stop working.`)) return
    const res = await fetch(`/api/employees/${id}/resend-link`, { method: 'POST' })
    if (res.ok) {
      const data = await res.json()
      window.open(data.whatsapp_url, '_blank')
      setCopiedId(id)
      setTimeout(() => setCopiedId(null), 2000)
    }
  }

  async function handleToggleAvail(id: string, current: boolean) {
    await fetch(`/api/employees/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_available: !current }),
    })
    fetchData()
  }

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' })
    router.push('/auth/login')
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-xl font-bold text-teal-700">CleanOps</h1>
          <div className="flex items-center gap-3">
            <Button onClick={() => setShowAdd(true)} size="sm">
              <Plus className="w-4 h-4 mr-1" /> Add Cleaner
            </Button>
            <button onClick={handleLogout} className="text-slate-400 hover:text-slate-600 p-1">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        {/* Status cards */}
        <ReadinessCards
          counts={overview}
          total={overview.total}
          activeFilter={filter}
          onFilter={setFilter}
        />

        {/* Employee list */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
          <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-slate-400" />
              <span className="font-semibold text-slate-800">
                {filter ? `${filtered.length} ${filter.replace('_', ' ').toLowerCase()}` : `${employees.length} cleaners`}
              </span>
            </div>
            <button
              onClick={() => setAvailableOnly(v => !v)}
              className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full border transition-colors
                ${availableOnly
                  ? 'bg-teal-50 border-teal-300 text-teal-700'
                  : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300'
                }`}
            >
              <Filter className="w-3 h-3" />
              {availableOnly ? 'Available only' : 'Show all'}
            </button>
          </div>

          {loading ? (
            <div className="flex justify-center py-12">
              <Spinner />
            </div>
          ) : employees.length === 0 ? (
            <EmptyState
              icon="🧹"
              title="No cleaners yet"
              description="Add your first cleaner and send them a WhatsApp link to get started."
              action={
                <Button onClick={() => setShowAdd(true)}>
                  <Plus className="w-4 h-4 mr-1" /> Add First Cleaner
                </Button>
              }
            />
          ) : (
            <EmployeeTable
              employees={filtered}
              onView={(id) => router.push(`/dashboard/employees/${id}`)}
              onWhatsApp={handleWhatsApp}
              onResend={handleResend}
              onToggleAvail={handleToggleAvail}
            />
          )}
        </div>
      </main>

      <AddEmployeeModal
        open={showAdd}
        onClose={() => setShowAdd(false)}
        onAdded={fetchData}
      />
    </div>
  )
}
