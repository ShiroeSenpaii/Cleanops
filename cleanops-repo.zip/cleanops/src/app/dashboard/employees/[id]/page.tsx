'use client'

import { useState, useEffect, use } from 'react'
import { useRouter } from 'next/navigation'
import { Badge, Button, Card, CardHeader, CardBody, Spinner } from '@/components/ui'
import { READINESS_CONFIG, STEP_STATUS_CONFIG } from '@/lib/utils'
import type { ReadinessStatus, StepStatus } from '@/lib/types'
import { ArrowLeft, MessageCircle, RefreshCw, FileText, CheckCircle, XCircle } from 'lucide-react'

export default function EmployeeDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const [employee, setEmployee] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [reviewing, setReviewing] = useState<string | null>(null)
  const [notes, setNotes] = useState<Record<string, string>>({})

  async function load() {
    setLoading(true)
    const res = await fetch(`/api/employees/${id}`)
    if (res.ok) {
      const data = await res.json()
      setEmployee(data.employee)
    }
    setLoading(false)
  }

  useEffect(() => { load() }, [id])

  async function review(submissionId: string, action: 'APPROVE' | 'REJECT') {
    setReviewing(submissionId)
    await fetch(`/api/submissions/${submissionId}/review`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, notes: notes[submissionId] ?? '' }),
    })
    setReviewing(null)
    load()
  }

  async function handleWhatsApp() {
    const res = await fetch(`/api/employees/${id}/whatsapp-link`)
    if (res.ok) {
      const data = await res.json()
      window.open(data.whatsapp_url, '_blank')
    }
  }

  async function handleResend() {
    if (!confirm('Regenerate this employee\'s magic link? The old one will stop working.')) return
    const res = await fetch(`/api/employees/${id}/resend-link`, { method: 'POST' })
    if (res.ok) {
      const data = await res.json()
      window.open(data.whatsapp_url, '_blank')
    }
  }

  async function viewDocument(filePath: string) {
    const res = await fetch(`/api/employees/${id}/document-url`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ file_path: filePath }),
    })
    if (res.ok) {
      const { url } = await res.json()
      window.open(url, '_blank')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner />
      </div>
    )
  }

  if (!employee) return <div className="p-8 text-slate-500">Employee not found.</div>

  const onboarding = employee.employee_onboardings?.[0]
  const submissions = onboarding?.step_submissions ?? []
  const approved = submissions.filter((s: any) => s.status === 'APPROVED').length
  const total = submissions.length

  let readiness: ReadinessStatus = 'IN_PROGRESS'
  if (approved === total && total > 0) readiness = 'READY'
  else if (submissions.some((s: any) => s.status === 'REJECTED')) readiness = 'BLOCKED'
  else if (submissions.some((s: any) => ['SUBMITTED','NEEDS_REVIEW'].includes(s.status))) readiness = 'NEEDS_REVIEW'

  const cfg = READINESS_CONFIG[readiness]

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => router.back()} className="text-slate-400 hover:text-slate-600">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-semibold text-slate-800 flex-1">{employee.full_name}</h1>
          <Badge className={cfg.className} dot dotColor={cfg.dot}>{cfg.label}</Badge>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6 space-y-4">
        {/* Employee info + actions */}
        <Card>
          <CardBody className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <p className="text-sm text-slate-500">{employee.phone ?? 'No phone'}</p>
              <p className="text-sm text-slate-500">{employee.email ?? 'No email'}</p>
              <p className="text-sm text-slate-400 mt-1">
                {approved}/{total} steps approved
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="secondary" size="sm" onClick={handleWhatsApp}>
                <MessageCircle className="w-4 h-4 mr-1" /> WhatsApp
              </Button>
              <Button variant="secondary" size="sm" onClick={handleResend}>
                <RefreshCw className="w-4 h-4 mr-1" /> Resend Link
              </Button>
            </div>
          </CardBody>
        </Card>

        {/* Steps */}
        <div className="space-y-3">
          {submissions.map((sub: any) => {
            const step = sub.template_steps
            const statusCfg = STEP_STATUS_CONFIG[sub.status as StepStatus]
            const canReview = ['SUBMITTED', 'NEEDS_REVIEW'].includes(sub.status)

            return (
              <Card key={sub.id}>
                <CardHeader className="flex items-center justify-between py-3">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-slate-800">{step.sort_order}. {step.title}</span>
                    {step.step_type === 'acknowledgment' && (
                      <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">Acknowledgment</span>
                    )}
                  </div>
                  <Badge className={statusCfg.className}>{statusCfg.label}</Badge>
                </CardHeader>

                {(sub.file_name || sub.notes_from_owner || canReview) && (
                  <CardBody className="pt-0 space-y-3">
                    {sub.file_name && (
                      <button
                        onClick={() => sub.file_path && viewDocument(sub.file_path)}
                        className="flex items-center gap-2 text-sm text-teal-600 hover:text-teal-700"
                      >
                        <FileText className="w-4 h-4" />
                        {sub.file_name}
                      </button>
                    )}

                    {sub.notes_from_owner && (
                      <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">
                        <strong>Your note:</strong> {sub.notes_from_owner}
                      </p>
                    )}

                    {canReview && (
                      <div className="space-y-2">
                        <textarea
                          placeholder="Rejection reason (required if rejecting)..."
                          rows={2}
                          value={notes[sub.id] ?? ''}
                          onChange={e => setNotes(n => ({ ...n, [sub.id]: e.target.value }))}
                          className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-200"
                        />
                        <div className="flex gap-2">
                          <Button
                            variant="secondary"
                            size="sm"
                            className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
                            loading={reviewing === sub.id}
                            onClick={() => review(sub.id, 'REJECT')}
                          >
                            <XCircle className="w-4 h-4 mr-1" /> Reject
                          </Button>
                          <Button
                            size="sm"
                            className="flex-1 bg-green-600 hover:bg-green-700"
                            loading={reviewing === sub.id}
                            onClick={() => review(sub.id, 'APPROVE')}
                          >
                            <CheckCircle className="w-4 h-4 mr-1" /> Approve
                          </Button>
                        </div>
                      </div>
                    )}
                  </CardBody>
                )}
              </Card>
            )
          })}
        </div>
      </main>
    </div>
  )
}
