'use client'

import { useState, useEffect, use, useCallback } from 'react'
import { PORTAL_STRINGS, ACCEPTED_EXTENSIONS, MAX_FILE_SIZE_BYTES, estimateMinutesRemaining } from '@/lib/utils'
import type { Language } from '@/lib/types'
import { CheckCircle, Upload, AlertCircle, Clock, WifiOff, ChevronDown, ChevronUp } from 'lucide-react'

export default function OnboardPortalPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = use(params)
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [lang, setLang] = useState<Language>('en')
  const [isOffline, setIsOffline] = useState(false)
  const [expandedSteps, setExpandedSteps] = useState(false)
  const [uploading, setUploading] = useState<string | null>(null)
  const [uploadError, setUploadError] = useState<string | null>(null)

  const t = (key: string) => PORTAL_STRINGS[lang][key] ?? key

  useEffect(() => {
    const onOffline = () => setIsOffline(true)
    const onOnline  = () => setIsOffline(false)
    window.addEventListener('offline', onOffline)
    window.addEventListener('online',  onOnline)
    return () => {
      window.removeEventListener('offline', onOffline)
      window.removeEventListener('online',  onOnline)
    }
  }, [])

  const load = useCallback(async () => {
    const res = await fetch(`/api/onboard/${token}`)
    if (res.ok) {
      const d = await res.json()
      setData(d)
      setLang(d.employee.preferred_language ?? 'en')
    }
    setLoading(false)
  }, [token])

  useEffect(() => { load() }, [load])

  async function switchLang(l: Language) {
    setLang(l)
    await fetch(`/api/onboard/${token}/set-language`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ language: l }),
    })
  }

  async function handleUpload(stepKey: string, file: File) {
    setUploadError(null)
    if (file.size > MAX_FILE_SIZE_BYTES) {
      setUploadError(t('fileTooLarge'))
      return
    }

    setUploading(stepKey)

    // 1. Get signed upload URL
    const urlRes = await fetch(`/api/onboard/${token}/upload-url`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        step_key:  stepKey,
        file_name: file.name,
        mime_type: file.type || 'application/octet-stream',
        file_size: file.size,
      }),
    })

    if (!urlRes.ok) {
      setUploadError('Upload failed. Please try again.')
      setUploading(null)
      return
    }

    const { signed_url, storage_path } = await urlRes.json()

    // 2. Upload directly to Supabase Storage
    const uploadRes = await fetch(signed_url, {
      method: 'PUT',
      body: file,
      headers: { 'Content-Type': file.type },
    })

    if (!uploadRes.ok) {
      setUploadError('Upload failed. Please try again.')
      setUploading(null)
      return
    }

    // 3. Submit the step
    const submitRes = await fetch(`/api/onboard/${token}/submit-step`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        step_key:        stepKey,
        file_path:       storage_path,
        file_name:       file.name,
        file_size_bytes: file.size,
        mime_type:       file.type,
      }),
    })

    setUploading(null)
    if (submitRes.ok) {
      load()
    } else {
      setUploadError('Submission failed. Please try again.')
    }
  }

  async function handleAcknowledge(stepKey: string) {
    setUploading(stepKey)
    await fetch(`/api/onboard/${token}/acknowledge-step`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ step_key: stepKey }),
    })
    setUploading(null)
    load()
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin w-8 h-8 border-4 border-teal-600 border-t-transparent rounded-full" />
      </div>
    )
  }

  if (!data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
        <div className="text-center">
          <div className="text-5xl mb-4">🔗</div>
          <h1 className="text-xl font-bold text-slate-800">Link not found</h1>
          <p className="text-slate-500 mt-2">This link may have expired. Contact your employer for a new one.</p>
        </div>
      </div>
    )
  }

  const { employee, company, steps, next_step_key, readiness_status, steps_approved, steps_total, minutes_left } = data
  const nextStep = steps.find((s: any) => s.step_key === next_step_key)
  const isReady = readiness_status === 'READY'
  const stepTitle = (s: any) => lang === 'es' ? s.title_es || s.title : s.title
  const stepDesc  = (s: any) => lang === 'es' ? s.description_es || s.description : s.description
  const progressPct = steps_total > 0 ? Math.round((steps_approved / steps_total) * 100) : 0

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Offline banner */}
      {isOffline && (
        <div className="bg-amber-500 text-white text-sm px-4 py-2 flex items-center gap-2 justify-center">
          <WifiOff className="w-4 h-4" />
          {t('offline')}
        </div>
      )}

      {/* Header */}
      <header className="bg-teal-700 text-white px-4 pt-safe-top pb-4">
        <div className="flex items-center justify-between mb-3">
          <span className="font-bold text-lg">CleanOps</span>
          {/* Language toggle */}
          <div className="flex rounded-full overflow-hidden border border-teal-500">
            {(['en', 'es'] as Language[]).map(l => (
              <button
                key={l}
                onClick={() => switchLang(l)}
                className={`px-3 py-1 text-sm font-medium transition-colors ${
                  lang === l ? 'bg-white text-teal-700' : 'text-teal-100 hover:bg-teal-600'
                }`}
              >
                {l.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
        <p className="text-teal-100 text-sm">{company.name}</p>
        <h1 className="text-2xl font-bold mt-0.5">
          {t('welcome')}, {employee.full_name.split(' ')[0]}! 👋
        </h1>

        {/* Progress bar */}
        {!isReady && (
          <div className="mt-3">
            <div className="flex items-center justify-between text-xs text-teal-200 mb-1">
              <span>
                {t('progress')
                  .replace('{current}', String(steps_approved))
                  .replace('{total}', String(steps_total))
                  .replace('{minutes}', String(minutes_left))}
              </span>
              <span>{progressPct}%</span>
            </div>
            <div className="h-2 bg-teal-900 rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full transition-all duration-500"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>
        )}
      </header>

      <main className="flex-1 px-4 py-6 max-w-lg mx-auto w-full space-y-5">
        {/* ── READY state ── */}
        {isReady && (
          <div className="bg-green-50 border-2 border-green-400 rounded-2xl p-8 text-center">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-2xl font-bold text-green-800">{t('done')}</h2>
            <p className="text-green-700 mt-2">{t('doneSubtitle')}</p>
          </div>
        )}

        {/* ── YOUR NEXT STEP card ── */}
        {!isReady && nextStep && (
          <div className="bg-white rounded-2xl border-2 border-teal-500 shadow-md overflow-hidden">
            <div className="bg-teal-600 px-4 py-2">
              <p className="text-xs font-bold text-teal-100 tracking-widest">{t('nextStep')}</p>
            </div>
            <div className="px-4 py-5">
              <h2 className="text-xl font-bold text-slate-900 mb-1">{stepTitle(nextStep)}</h2>
              <p className="text-slate-600 text-sm mb-4 leading-relaxed">{stepDesc(nextStep)}</p>

              {/* Training GIF */}
              {nextStep.video_gif_url && (
                <img
                  src={nextStep.video_gif_url}
                  alt="How-to guide"
                  className="w-full rounded-xl mb-4 max-h-40 object-cover"
                />
              )}

              {uploadError && (
                <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg mb-3">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {uploadError}
                </div>
              )}

              {/* Status-specific UI */}
              <StepAction
                step={nextStep}
                token={token}
                lang={lang}
                t={t}
                uploading={uploading}
                onUpload={handleUpload}
                onAcknowledge={handleAcknowledge}
              />
            </div>
          </div>
        )}

        {/* ── All steps list ── */}
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <button
            onClick={() => setExpandedSteps(v => !v)}
            className="w-full px-4 py-3 flex items-center justify-between text-sm font-medium text-slate-700"
          >
            <span className="flex items-center gap-2">
              <span>{t('allSteps')}</span>
              <span className="text-xs bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full">
                {steps_approved}/{steps_total}
              </span>
            </span>
            {expandedSteps ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {expandedSteps && (
            <div className="border-t border-slate-100 divide-y divide-slate-100">
              {steps.map((s: any) => (
                <div key={s.step_key} className="px-4 py-3 flex items-center gap-3">
                  <StepIcon status={s.status} />
                  <span className={`text-sm ${s.status === 'APPROVED' ? 'text-slate-400 line-through' : 'text-slate-700'}`}>
                    {stepTitle(s)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Chat with owner */}
        {company.phone && (
          <a
            href={`https://wa.me/${company.phone.replace(/\D/g, '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 text-sm text-teal-700 hover:text-teal-800 py-2"
          >
            💬 {t('chatOwner')}
          </a>
        )}
      </main>
    </div>
  )
}

function StepIcon({ status }: { status: string }) {
  if (status === 'APPROVED')   return <CheckCircle className="w-5 h-5 text-green-500 shrink-0" />
  if (status === 'REJECTED')   return <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
  if (status === 'SUBMITTED' || status === 'NEEDS_REVIEW')
    return <Clock className="w-5 h-5 text-amber-500 shrink-0" />
  return <div className="w-5 h-5 rounded-full border-2 border-slate-300 shrink-0" />
}

function StepAction({ step, token, lang, t, uploading, onUpload, onAcknowledge }: {
  step: any
  token: string
  lang: Language
  t: (k: string) => string
  uploading: string | null
  onUpload: (key: string, file: File) => void
  onAcknowledge: (key: string) => void
}) {
  const isLoading = uploading === step.step_key

  if (step.status === 'SUBMITTED' || step.status === 'NEEDS_REVIEW') {
    return (
      <div className="flex items-center gap-2 text-amber-700 bg-amber-50 px-4 py-3 rounded-xl text-sm">
        <Clock className="w-4 h-4 shrink-0" />
        {t('submitted')}
      </div>
    )
  }

  if (step.status === 'REJECTED') {
    return (
      <div className="space-y-3">
        {step.notes_from_owner && (
          <div className="bg-red-50 border border-red-200 px-3 py-2 rounded-xl text-sm text-red-700">
            <strong>Why:</strong> {step.notes_from_owner}
          </div>
        )}
        <UploadButton stepKey={step.step_key} label={t('reUpload')} loading={isLoading} onUpload={onUpload} />
      </div>
    )
  }

  // NOT_STARTED
  if (step.step_type === 'document_upload') {
    return <UploadButton stepKey={step.step_key} label={t('upload')} loading={isLoading} onUpload={onUpload} />
  }

  // acknowledgment
  return (
    <button
      disabled={isLoading}
      onClick={() => onAcknowledge(step.step_key)}
      className="w-full bg-teal-600 text-white font-semibold py-4 rounded-xl text-base active:bg-teal-800 disabled:opacity-60 transition-colors"
    >
      {isLoading ? '…' : t('acknowledge')}
    </button>
  )
}

function UploadButton({ stepKey, label, loading, onUpload }: {
  stepKey: string
  label: string
  loading: boolean
  onUpload: (key: string, file: File) => void
}) {
  return (
    <label className={`flex items-center justify-center gap-2 w-full py-4 rounded-xl font-semibold text-base cursor-pointer transition-colors
      ${loading ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-teal-600 text-white active:bg-teal-800'}`}>
      <Upload className="w-5 h-5" />
      {loading ? '…' : label}
      <input
        type="file"
        accept={ACCEPTED_EXTENSIONS}
        className="sr-only"
        disabled={loading}
        onChange={e => {
          const file = e.target.files?.[0]
          if (file) onUpload(stepKey, file)
        }}
      />
    </label>
  )
}
