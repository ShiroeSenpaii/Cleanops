import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET() {
  const supabase = await createClient()

  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: owner } = await supabase
    .from('owners')
    .select('company_id')
    .eq('user_id', user.id)
    .single()

  if (!owner) return NextResponse.json({ error: 'Owner not found' }, { status: 404 })

  // Get readiness counts using the Postgres function
  const { data: overview, error } = await supabase
    .rpc('get_company_overview', { p_company_id: owner.company_id })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Normalize into a flat object
  const counts = {
    READY:        0,
    IN_PROGRESS:  0,
    NEEDS_REVIEW: 0,
    BLOCKED:      0,
    total:        0,
  }

  for (const row of overview ?? []) {
    const key = row.readiness_status as keyof typeof counts
    if (key in counts) {
      counts[key] = Number(row.employee_count)
      counts.total += Number(row.employee_count)
    }
  }

  return NextResponse.json(counts)
}
