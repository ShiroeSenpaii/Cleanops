import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { z } from 'zod'

const ReviewSchema = z.object({
  action: z.enum(['APPROVE', 'REJECT']),
  notes:  z.string().optional(),
})

// POST /api/submissions/[id]/review
export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: owner } = await supabase
    .from('owners')
    .select('id, company_id')
    .eq('user_id', user.id)
    .single()
  if (!owner) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const parsed = ReviewSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid input' }, { status: 400 })
  }

  const newStatus = parsed.data.action === 'APPROVE' ? 'APPROVED' : 'REJECTED'

  const { data, error } = await supabase
    .from('step_submissions')
    .update({
      status:           newStatus,
      notes_from_owner: parsed.data.notes ?? null,
      reviewed_at:      new Date().toISOString(),
      reviewed_by:      owner.id,
    })
    .eq('id', id)
    .eq('company_id', owner.company_id) // RLS double-check
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({ submission: data })
}
