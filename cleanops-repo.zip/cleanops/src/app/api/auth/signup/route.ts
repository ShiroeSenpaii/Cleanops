import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { seedCompanyTemplate } from '@/lib/seed'
import { slugify } from '@/lib/utils'
import { z } from 'zod'

const SignupSchema = z.object({
  full_name:    z.string().min(2),
  company_name: z.string().min(2),
  email:        z.string().email(),
  password:     z.string().min(8),
  phone:        z.string().optional(),
})

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const parsed = SignupSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 })
    }

    const { full_name, company_name, email, password, phone } = parsed.data
    const supabase = createAdminClient()

    // 1. Create auth user
    const { data: authData, error: authErr } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    })
    if (authErr || !authData.user) {
      return NextResponse.json({ error: authErr?.message ?? 'Auth creation failed' }, { status: 400 })
    }

    const userId = authData.user.id

    // 2. Create company
    const slug = slugify(company_name) + '-' + Math.random().toString(36).slice(2, 6)
    const { data: company, error: compErr } = await supabase
      .from('companies')
      .insert({ name: company_name, slug, phone: phone ?? null })
      .select('id')
      .single()

    if (compErr || !company) {
      await supabase.auth.admin.deleteUser(userId)
      return NextResponse.json({ error: 'Company creation failed' }, { status: 500 })
    }

    // 3. Create owner record
    const { error: ownerErr } = await supabase
      .from('owners')
      .insert({ user_id: userId, company_id: company.id, full_name, email })

    if (ownerErr) {
      await supabase.auth.admin.deleteUser(userId)
      return NextResponse.json({ error: 'Owner creation failed' }, { status: 500 })
    }

    // 4. Seed template + steps
    await seedCompanyTemplate(supabase, company.id)

    return NextResponse.json({ success: true }, { status: 201 })
  } catch (err) {
    console.error('[signup]', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
