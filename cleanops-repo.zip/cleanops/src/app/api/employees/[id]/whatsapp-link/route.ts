import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { generateWhatsAppInvite } from '@/lib/utils'
import { nanoid } from 'nanoid'

// GET /api/employees/[id]/whatsapp-link
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: owner } = await supabase
    .from('owners')
    .select('company_id, companies(name)')
    .eq('user_id', user.id)
    .single()

  const { data: employee } = await supabase
    .from('employees')
    .select('full_name, onboard_token, phone')
    .eq('id', id)
    .single()

  if (!employee) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const companyName = (owner?.companies as { name?: string } | null)?.name ?? 'Your Company'
  const waUrl = generateWhatsAppInvite(employee.full_name, companyName, employee.onboard_token)

  // Log the send
  await supabase.from('message_logs').insert({
    company_id:   owner?.company_id,
    employee_id:  id,
    channel:      'whatsapp',
    message_type: 'onboarding_invite',
    link_url:     waUrl,
  })

  return NextResponse.json({ whatsapp_url: waUrl, portal_url: `${process.env.NEXT_PUBLIC_APP_URL}/onboard/${employee.onboard_token}` })
}
