import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { generateWhatsAppInvite } from '@/lib/utils'
import { nanoid } from 'nanoid'

// POST /api/employees/[id]/resend-link
export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: owner } = await supabase
    .from('owners')
    .select('company_id, companies(name)')
    .eq('user_id', user.id)
    .single()

  // Generate a new token
  const newToken = nanoid(21)

  const { data: employee, error } = await supabase
    .from('employees')
    .update({ onboard_token: newToken })
    .eq('id', id)
    .select('full_name, phone')
    .single()

  if (error || !employee) {
    return NextResponse.json({ error: 'Update failed' }, { status: 500 })
  }

  const companyName = (owner?.companies as { name?: string } | null)?.name ?? 'Your Company'
  const waUrl = generateWhatsAppInvite(employee.full_name, companyName, newToken)

  await supabase.from('message_logs').insert({
    company_id:   owner?.company_id,
    employee_id:  id,
    channel:      'whatsapp',
    message_type: 'onboarding_invite',
    link_url:     waUrl,
  })

  return NextResponse.json({
    whatsapp_url: waUrl,
    new_token:    newToken,
    portal_url:   `${process.env.NEXT_PUBLIC_APP_URL}/onboard/${newToken}`,
  })
}
