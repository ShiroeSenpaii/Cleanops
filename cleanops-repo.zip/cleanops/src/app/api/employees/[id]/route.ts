import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { z } from 'zod'

const UpdateSchema = z.object({
  full_name:          z.string().min(2).optional(),
  phone:              z.string().optional(),
  email:              z.string().email().optional().or(z.literal('')),
  notes:              z.string().optional(),
  is_available:       z.boolean().optional(),
  preferred_language: z.enum(['en', 'es']).optional(),
  is_active:          z.boolean().optional(),
})

// GET /api/employees/[id]
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: employee, error } = await supabase
    .from('employees')
    .select(`
      *,
      employee_onboardings (
        id,
        started_at,
        completed_at,
        step_submissions (
          *,
          template_steps (
            step_key,
            title,
            title_es,
            description,
            description_es,
            step_type,
            sort_order,
            is_required
          )
        )
      )
    `)
    .eq('id', id)
    .single()

  if (error || !employee) {
    return NextResponse.json({ error: 'Employee not found' }, { status: 404 })
  }

  // Sort submissions by step sort_order
  const onboarding = employee.employee_onboardings?.[0]
  if (onboarding?.step_submissions) {
    onboarding.step_submissions.sort(
      (a: { template_steps: { sort_order: number } }, b: { template_steps: { sort_order: number } }) =>
        a.template_steps.sort_order - b.template_steps.sort_order
    )
  }

  return NextResponse.json({ employee })
}

// PATCH /api/employees/[id]
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const parsed = UpdateSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 })
  }

  const { data, error } = await supabase
    .from('employees')
    .update(parsed.data)
    .eq('id', id)
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ employee: data })
}

// DELETE /api/employees/[id] — soft delete only
export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { error } = await supabase
    .from('employees')
    .update({ is_active: false })
    .eq('id', id)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ success: true })
}
