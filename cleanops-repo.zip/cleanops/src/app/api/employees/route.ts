import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { seedEmployeeSubmissions } from '@/lib/seed'
import { generateWhatsAppInvite } from '@/lib/utils'
import { z } from 'zod'
import { nanoid } from 'nanoid'

const CreateEmployeeSchema = z.object({
  full_name: z.string().min(2),
  phone:     z.string().optional(),
  email:     z.string().email().optional().or(z.literal('')),
  notes:     z.string().optional(),
})

// GET /api/employees — list all employees with readiness
export async function GET(req: Request) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: owner } = await supabase
    .from('owners')
    .select('company_id')
    .eq('user_id', user.id)
    .single()
  if (!owner) return NextResponse.json({ error: 'Owner not found' }, { status: 404 })

  // Parse filters from query string
  const url = new URL(req.url)
  const availableOnly = url.searchParams.get('available') === 'true'

  // Fetch employees + their onboarding + submission counts
  let query = supabase
    .from('employees')
    .select(`
      *,
      employee_onboardings (
        id,
        completed_at,
        step_submissions (
          status,
          template_step_id,
          reminder_count,
          reminder_sent_at
        )
      )
    `)
    .eq('company_id', owner.company_id)
    .eq('is_active', true)
    .order('full_name')

  if (availableOnly) {
    query = query.eq('is_available', true)
  }

  const { data: employees, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Compute readiness per employee
  const result = (employees ?? []).map((emp) => {
    const onboarding = emp.employee_onboardings?.[0]
    const submissions = onboarding?.step_submissions ?? []

    const total    = submissions.length
    const approved = submissions.filter((s: { status: string }) => s.status === 'APPROVED').length
    const rejected = submissions.filter((s: { status: string }) => s.status === 'REJECTED').length
    const pending  = submissions.filter((s: { status: string }) =>
      s.status === 'SUBMITTED' || s.status === 'NEEDS_REVIEW'
    ).length

    let readiness_status: string
    if (approved === total && total > 0) readiness_status = 'READY'
    else if (rejected > 0)              readiness_status = 'BLOCKED'
    else if (pending > 0)               readiness_status = 'NEEDS_REVIEW'
    else                                readiness_status = 'IN_PROGRESS'

    return {
      id:               emp.id,
      full_name:        emp.full_name,
      phone:            emp.phone,
      email:            emp.email,
      is_available:     emp.is_available,
      preferred_language: emp.preferred_language,
      notes:            emp.notes,
      onboard_token:    emp.onboard_token,
      onboarding_id:    onboarding?.id ?? null,
      readiness_status,
      steps_approved:   approved,
      steps_total:      total,
      created_at:       emp.created_at,
      updated_at:       emp.updated_at,
    }
  })

  return NextResponse.json({ employees: result })
}

// POST /api/employees — create a new employee
export async function POST(req: Request) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: owner } = await supabase
    .from('owners')
    .select('company_id')
    .eq('user_id', user.id)
    .single()
  if (!owner) return NextResponse.json({ error: 'Owner not found' }, { status: 404 })

  const body = await req.json()
  const parsed = CreateEmployeeSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 })
  }

  const { full_name, phone, email, notes } = parsed.data

  // Get the active template for this company
  const { data: template } = await supabase
    .from('onboarding_templates')
    .select('id')
    .eq('company_id', owner.company_id)
    .eq('is_active', true)
    .single()

  if (!template) {
    return NextResponse.json({ error: 'No active template found' }, { status: 404 })
  }

  // Use admin client to generate token and create records
  const admin = createAdminClient()
  const token = nanoid(21)

  // Create employee
  const { data: employee, error: empErr } = await admin
    .from('employees')
    .insert({
      company_id:    owner.company_id,
      full_name,
      phone:         phone ?? null,
      email:         email || null,
      notes:         notes ?? null,
      onboard_token: token,
    })
    .select('id')
    .single()

  if (empErr || !employee) {
    return NextResponse.json({ error: empErr?.message ?? 'Employee creation failed' }, { status: 500 })
  }

  // Create onboarding instance
  const { data: onboarding, error: onbErr } = await admin
    .from('employee_onboardings')
    .insert({
      employee_id: employee.id,
      template_id: template.id,
      company_id:  owner.company_id,
    })
    .select('id')
    .single()

  if (onbErr || !onboarding) {
    return NextResponse.json({ error: 'Onboarding creation failed' }, { status: 500 })
  }

  // Seed step submissions
  await seedEmployeeSubmissions(admin, {
    employeeId:   employee.id,
    onboardingId: onboarding.id,
    companyId:    owner.company_id,
    templateId:   template.id,
  })

  // Log the invite
  const whatsappUrl = generateWhatsAppInvite(
    full_name,
    '', // company name filled on client
    token
  )

  await admin.from('message_logs').insert({
    company_id:   owner.company_id,
    employee_id:  employee.id,
    owner_id:     owner.company_id, // resolved to owner id via lookup if needed
    channel:      'whatsapp',
    message_type: 'onboarding_invite',
    link_url:     whatsappUrl,
  })

  return NextResponse.json({
    employee_id:   employee.id,
    onboarding_id: onboarding.id,
    onboard_token: token,
  }, { status: 201 })
}
