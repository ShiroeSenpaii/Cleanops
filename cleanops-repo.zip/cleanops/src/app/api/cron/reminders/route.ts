import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { generateWhatsAppReminder } from '@/lib/utils'

// POST /api/cron/reminders
// Called by Vercel Cron every 24 hours.
// Configure in vercel.json: { "crons": [{ "path": "/api/cron/reminders", "schedule": "0 10 * * *" }] }

export async function POST(req: Request) {
  // Verify cron secret so this can't be called publicly
  const authHeader = req.headers.get('authorization')
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const supabase = createAdminClient()

  // Get all stale submissions (not updated in 48 hours, < 3 reminders sent)
  const { data: stale, error } = await supabase
    .rpc('get_stale_submissions', { p_hours: 48 })

  if (error) {
    console.error('[cron/reminders] RPC error:', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  if (!stale || stale.length === 0) {
    return NextResponse.json({ sent: 0, message: 'No stale submissions' })
  }

  let sent = 0
  const logs = []

  for (const row of stale) {
    const waUrl = generateWhatsAppReminder(
      row.employee_name,
      row.step_title,
      row.onboard_token
    )

    // Update the submission
    await supabase
      .from('step_submissions')
      .update({
        reminder_sent_at: new Date().toISOString(),
        reminder_count:   (row.reminder_count ?? 0) + 1,
      })
      .eq('id', row.submission_id)

    // Log the reminder
    logs.push({
      company_id:   row.company_id,
      employee_id:  row.employee_id,
      channel:      'whatsapp',
      message_type: 'reminder',
      link_url:     waUrl,
    })

    sent++
  }

  if (logs.length > 0) {
    await supabase.from('message_logs').insert(logs)
  }

  console.log(`[cron/reminders] Sent ${sent} reminder(s)`)
  return NextResponse.json({ sent })
}
