import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { buildStoragePath, ACCEPTED_MIME_TYPES, MAX_FILE_SIZE_BYTES } from '@/lib/utils'
import { z } from 'zod'

const UploadUrlSchema = z.object({
  step_key:  z.string(),
  file_name: z.string(),
  mime_type: z.string(),
  file_size: z.number().max(MAX_FILE_SIZE_BYTES),
})

// POST /api/onboard/[token]/upload-url
export async function POST(
  req: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params
  const supabase = createAdminClient()

  const { data: employee } = await supabase
    .from('employees')
    .select('id, company_id, is_active')
    .eq('onboard_token', token)
    .single()

  if (!employee || !employee.is_active) {
    return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
  }

  const body = await req.json()
  const parsed = UploadUrlSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid input' }, { status: 400 })
  }

  const { step_key, file_name, mime_type, file_size } = parsed.data

  if (!ACCEPTED_MIME_TYPES.includes(mime_type)) {
    return NextResponse.json({ error: 'File type not allowed' }, { status: 400 })
  }

  if (file_size > MAX_FILE_SIZE_BYTES) {
    return NextResponse.json({ error: 'File too large' }, { status: 400 })
  }

  const storagePath = buildStoragePath(
    employee.company_id,
    employee.id,
    step_key,
    file_name
  )

  const { data, error } = await supabase.storage
    .from('employee-documents')
    .createSignedUploadUrl(storagePath)

  if (error || !data) {
    return NextResponse.json({ error: 'Could not generate upload URL' }, { status: 500 })
  }

  return NextResponse.json({
    signed_url:   data.signedUrl,
    storage_path: storagePath,
    token:        data.token,
  })
}
