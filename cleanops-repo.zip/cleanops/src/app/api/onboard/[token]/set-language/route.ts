import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { z } from 'zod'

const Schema = z.object({ language: z.enum(['en', 'es']) })

// POST /api/onboard/[token]/set-language
export async function POST(
  req: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params
  const supabase = createAdminClient()

  const { data: employee } = await supabase
    .from('employees')
    .select('id, is_active')
    .eq('onboard_token', token)
    .single()

  if (!employee || !employee.is_active) {
    return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
  }

  const body = await req.json()
  const parsed = Schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 })

  await supabase
    .from('employees')
    .update({ preferred_language: parsed.data.language })
    .eq('id', employee.id)

  return NextResponse.json({ success: true })
}
