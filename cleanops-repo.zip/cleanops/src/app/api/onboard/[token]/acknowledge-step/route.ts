import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { z } from 'zod'

// POST /api/onboard/[token]/acknowledge-step
export async function POST(
  req: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params
  const supabase = createAdminClient()

  const { data: employee } = await supabase
    .from('employees')
    .select('id, company_id, is_active')
    .eq('onboard_token', token)
    .single()

  if (!employee || !employee.is_active) {
    return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
  }

  const { step_key } = await req.json()
  if (!step_key) return NextResponse.json({ error: 'step_key required' }, { status: 400 })

  const { data: subViaStep } = await supabase
    .from('step_submissions')
    .select(`id, template_steps!inner(step_key, step_type)`)
    .eq('employee_id', employee.id)
    .eq('template_steps.step_key', step_key)
    .single()

  if (!subViaStep) {
    return NextResponse.json({ error: 'Step not found' }, { status: 404 })
  }

  if ((subViaStep as any).template_steps.step_type !== 'acknowledgment') {
    return NextResponse.json({ error: 'Step is not an acknowledgment type' }, { status: 400 })
  }

  const { error } = await supabase
    .from('step_submissions')
    .update({
      status:       'SUBMITTED',
      submitted_at: new Date().toISOString(),
    })
    .eq('id', subViaStep.id)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ success: true })
}
