import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { z } from 'zod'

const SubmitSchema = z.object({
  step_key:       z.string(),
  file_path:      z.string(),
  file_name:      z.string(),
  file_size_bytes: z.number(),
  mime_type:      z.string(),
})

// POST /api/onboard/[token]/submit-step
export async function POST(
  req: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params
  const supabase = createAdminClient()

  const { data: employee } = await supabase
    .from('employees')
    .select('id, company_id, is_active')
    .eq('onboard_token', token)
    .single()

  if (!employee || !employee.is_active) {
    return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
  }

  const body = await req.json()
  const parsed = SubmitSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid input' }, { status: 400 })
  }

  const { step_key, file_path, file_name, file_size_bytes, mime_type } = parsed.data

  // Find the step submission to update
  const { data: submission, error: findErr } = await supabase
    .from('step_submissions')
    .select('id')
    .eq('employee_id', employee.id)
    .eq('company_id', employee.company_id)
    .filter('template_steps.step_key', 'eq', step_key)
    .single()

  // Alternative: join through onboarding to find by step_key
  const { data: subViaStep } = await supabase
    .from('step_submissions')
    .select(`
      id,
      template_steps!inner(step_key)
    `)
    .eq('employee_id', employee.id)
    .eq('template_steps.step_key', step_key)
    .single()

  const submissionId = subViaStep?.id
  if (!submissionId) {
    return NextResponse.json({ error: 'Step not found' }, { status: 404 })
  }

  const { error } = await supabase
    .from('step_submissions')
    .update({
      status:          'SUBMITTED',
      file_path,
      file_name,
      file_size_bytes,
      mime_type,
      submitted_at:    new Date().toISOString(),
      notes_from_owner: null, // clear any previous rejection note
    })
    .eq('id', submissionId)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({ success: true })
}
