import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { estimateMinutesRemaining } from '@/lib/utils'

// GET /api/onboard/[token]
// Token-gated — no auth required. Uses admin client to bypass RLS.
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params
  if (!token || token.length < 10) {
    return NextResponse.json({ error: 'Invalid token' }, { status: 400 })
  }

  const supabase = createAdminClient()

  // Fetch employee by token
  const { data: employee, error: empErr } = await supabase
    .from('employees')
    .select('id, full_name, preferred_language, is_active, onboard_token, company_id')
    .eq('onboard_token', token)
    .single()

  if (empErr || !employee || !employee.is_active) {
    return NextResponse.json({ error: 'Invalid or expired link' }, { status: 404 })
  }

  // Fetch company name and phone
  const { data: company } = await supabase
    .from('companies')
    .select('name, phone')
    .eq('id', employee.company_id)
    .single()

  // Fetch onboarding + steps + submissions
  const { data: onboarding } = await supabase
    .from('employee_onboardings')
    .select(`
      id,
      started_at,
      completed_at,
      step_submissions (
        id,
        status,
        file_name,
        notes_from_owner,
        submitted_at,
        reminder_count,
        template_step_id,
        template_steps (
          id,
          step_key,
          title,
          title_es,
          description,
          description_es,
          video_gif_url,
          step_type,
          is_required,
          sort_order
        )
      )
    `)
    .eq('employee_id', employee.id)
    .single()

  if (!onboarding) {
    return NextResponse.json({ error: 'Onboarding not found' }, { status: 404 })
  }

  // Mark onboarding as started if first visit
  if (!onboarding.started_at) {
    await supabase
      .from('employee_onboardings')
      .update({ started_at: new Date().toISOString() })
      .eq('id', onboarding.id)
  }

  // Sort submissions by step sort_order
  const submissions = (onboarding.step_submissions as any[]).sort(
    (a, b) => a.template_steps.sort_order - b.template_steps.sort_order
  )

  // Compute readiness
  const total    = submissions.length
  const approved = submissions.filter(s => s.status === 'APPROVED').length
  const rejected = submissions.filter(s => s.status === 'REJECTED').length
  const pending  = submissions.filter(s => s.status === 'SUBMITTED' || s.status === 'NEEDS_REVIEW').length

  let readiness_status: string
  if (approved === total && total > 0) readiness_status = 'READY'
  else if (rejected > 0)              readiness_status = 'BLOCKED'
  else if (pending > 0)               readiness_status = 'NEEDS_REVIEW'
  else                                readiness_status = 'IN_PROGRESS'

  // Find the next incomplete step
  const nextStep = submissions.find(
    s => s.status !== 'APPROVED' && s.template_steps.is_required
  )

  const minutesLeft = estimateMinutesRemaining(
    submissions.map(s => ({ step_key: s.template_steps.step_key, status: s.status }))
  )

  return NextResponse.json({
    employee: {
      id:                 employee.id,
      full_name:          employee.full_name,
      preferred_language: employee.preferred_language,
    },
    company: {
      name:  company?.name ?? '',
      phone: company?.phone ?? null,
    },
    onboarding_id:   onboarding.id,
    readiness_status,
    next_step_key:   nextStep?.template_steps.step_key ?? null,
    minutes_left:    minutesLeft,
    steps_approved:  approved,
    steps_total:     total,
    steps: submissions.map(s => ({
      submission_id:  s.id,
      step_key:       s.template_steps.step_key,
      title:          s.template_steps.title,
      title_es:       s.template_steps.title_es,
      description:    s.template_steps.description,
      description_es: s.template_steps.description_es,
      video_gif_url:  s.template_steps.video_gif_url,
      step_type:      s.template_steps.step_type,
      is_required:    s.template_steps.is_required,
      sort_order:     s.template_steps.sort_order,
      status:         s.status,
      file_name:      s.file_name,
      notes_from_owner: s.notes_from_owner,
      submitted_at:   s.submitted_at,
    })),
  })
}
