'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button, Input } from '@/components/ui'
import Link from 'next/link'

export default function SignupPage() {
  const router = useRouter()
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError('')
    setLoading(true)

    const form = new FormData(e.currentTarget)
    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        full_name:    form.get('full_name'),
        company_name: form.get('company_name'),
        email:        form.get('email'),
        password:     form.get('password'),
        phone:        form.get('phone'),
      }),
    })

    if (!res.ok) {
      const data = await res.json()
      setError(data.error ?? 'Signup failed')
      setLoading(false)
      return
    }

    // Auto sign-in after signup
    const { createClient } = await import('@/lib/supabase/client')
    const supabase = createClient()
    await supabase.auth.signInWithPassword({
      email:    form.get('email') as string,
      password: form.get('password') as string,
    })

    router.push('/setup')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4 py-12">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-teal-700">CleanOps</h1>
          <p className="text-slate-500 mt-1 text-sm">Create your account — takes 2 minutes</p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm px-6 py-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input id="full_name" name="full_name" label="Your Name" placeholder="Alex Johnson" required />
            <Input id="company_name" name="company_name" label="Company Name" placeholder="Sparkle Clean Co." required />
            <Input id="email" name="email" label="Email" type="email" placeholder="alex@sparkleclean.com" required />
            <Input id="phone" name="phone" label="Phone (optional)" type="tel" placeholder="+1 555 000 0000" hint="Shown to employees for questions" />
            <Input
              id="password"
              name="password"
              label="Password"
              type="password"
              placeholder="Min 8 characters"
              minLength={8}
              required
            />

            {error && (
              <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{error}</p>
            )}

            <Button type="submit" className="w-full" size="lg" loading={loading}>
              Create Account
            </Button>
          </form>
        </div>

        <p className="text-center text-sm text-slate-500 mt-4">
          Already have an account?{' '}
          <Link href="/auth/login" className="text-teal-600 font-medium hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  )
}
