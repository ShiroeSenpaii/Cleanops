# CleanOps

> Workforce onboarding and readiness tool for cleaning businesses.
> Know exactly which cleaners are ready to work.

## Tech Stack

- **Next.js 14** (App Router, TypeScript)
- **Supabase** (Postgres, Auth, Storage)
- **Tailwind CSS**
- **Deployed on Vercel**

---

## Getting Started

### 1. Clone and install

```bash
git clone https://github.com/your-username/cleanops.git
cd cleanops
npm install
```

### 2. Create your Supabase project

1. Go to [supabase.com](https://supabase.com) and create a new project
2. Wait for it to provision (~2 minutes)

### 3. Set up environment variables

```bash
cp .env.local.example .env.local
```

Fill in your values from **Supabase Dashboard → Settings → API**:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-ref.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_APP_URL=http://localhost:3000
CRON_SECRET=any-random-string-you-generate
```

### 4. Run database migrations

In your **Supabase Dashboard → SQL Editor**, run each migration file in order:

```
supabase/migrations/001_schema.sql
supabase/migrations/002_rls.sql
supabase/migrations/003_functions.sql
supabase/migrations/004_seed.sql
```

Or with the Supabase CLI (if installed):

```bash
supabase db push
```

### 5. Create the Storage bucket

In **Supabase Dashboard → Storage**:
1. Create a new bucket called `employee-documents`
2. Set it to **Private**
3. Add the RLS policies from the comments in `002_rls.sql`

### 6. Run the app

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) and sign up.

---

## Project Structure

```
cleanops/
├── supabase/
│   ├── migrations/          # All SQL migrations (run in order)
│   └── config.toml          # Local Supabase config
├── src/
│   ├── app/
│   │   ├── api/             # All API routes
│   │   │   ├── auth/        # signup, login, logout
│   │   │   ├── employees/   # CRUD + WhatsApp link
│   │   │   ├── submissions/ # review (approve/reject)
│   │   │   ├── onboard/     # token-gated employee portal API
│   │   │   └── cron/        # auto-reminder job
│   │   ├── auth/            # login + signup pages
│   │   ├── dashboard/       # owner dashboard + employee detail
│   │   └── onboard/[token]/ # employee portal (mobile)
│   ├── components/
│   │   ├── ui/              # Button, Badge, Input, Card, Modal
│   │   └── dashboard/       # ReadinessCards, EmployeeTable, etc.
│   └── lib/
│       ├── supabase/        # client, server, admin clients
│       ├── types.ts         # all TypeScript types
│       ├── utils.ts         # helpers, i18n strings, WhatsApp URLs
│       └── seed.ts          # template + submission seeding
├── middleware.ts             # Route protection
└── vercel.json              # Cron job config
```

---

## Key Design Decisions

**Two separate surfaces:** Owner dashboard uses Supabase Auth (cookie sessions). Employee portal uses a nanoid(21) token in the URL — no login, no app download.

**RLS everywhere:** Owners can only see their own company's data. Enforced at the Postgres level, not just in application code.

**Computed readiness:** Employee status (READY/IN_PROGRESS/NEEDS_REVIEW/BLOCKED) is computed by a Postgres function from step states — never stored as a denormalized field.

**Auto-reminders via Vercel Cron:** Fires daily at 10am, nudges employees who have had a step stuck for 48+ hours. Maximum 3 nudges per step to avoid spam.

---

## Deploying to Vercel

1. Push to GitHub
2. Connect repo to Vercel
3. Add all environment variables in Vercel project settings
4. Deploy — cron job activates automatically from `vercel.json`

---

## Environment Variables Reference

| Variable | Required | Description |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Yes | Your Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Yes | Public anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Yes | Service role key (server only) |
| `NEXT_PUBLIC_APP_URL` | Yes | Full app URL (no trailing slash) |
| `CRON_SECRET` | Yes | Random string to secure cron endpoint |
| `TWILIO_ACCOUNT_SID` | No | For SMS reminders (optional) |
| `TWILIO_AUTH_TOKEN` | No | For SMS reminders (optional) |
| `TWILIO_PHONE_NUMBER` | No | For SMS reminders (optional) |
