-- ============================================================
-- CleanOps — Migration 003: Functions & Triggers
-- ============================================================

-- ── Compute employee readiness status ────────────────────
CREATE OR REPLACE FUNCTION get_employee_readiness(p_onboarding_id UUID)
RETURNS TEXT AS $$
DECLARE
  total_required  INT;
  total_approved  INT;
  total_rejected  INT;
  total_pending   INT;  -- SUBMITTED or NEEDS_REVIEW
BEGIN
  SELECT
    COUNT(*) FILTER (WHERE ts.is_required = true),
    COUNT(*) FILTER (WHERE ss.status = 'APPROVED' AND ts.is_required = true),
    COUNT(*) FILTER (WHERE ss.status = 'REJECTED'),
    COUNT(*) FILTER (WHERE ss.status IN ('SUBMITTED', 'NEEDS_REVIEW'))
  INTO total_required, total_approved, total_rejected, total_pending
  FROM step_submissions ss
  JOIN template_steps ts ON ts.id = ss.template_step_id
  WHERE ss.onboarding_id = p_onboarding_id;

  IF total_approved >= total_required AND total_required > 0 THEN
    RETURN 'READY';
  ELSIF total_rejected > 0 THEN
    RETURN 'BLOCKED';
  ELSIF total_pending > 0 THEN
    RETURN 'NEEDS_REVIEW';
  ELSE
    RETURN 'IN_PROGRESS';
  END IF;
END;
$$ LANGUAGE plpgsql STABLE;

-- ── Mark onboarding complete when all steps approved ──────
CREATE OR REPLACE FUNCTION check_onboarding_complete()
RETURNS TRIGGER AS $$
DECLARE
  v_onboarding_id  UUID;
  v_readiness      TEXT;
BEGIN
  v_onboarding_id := NEW.onboarding_id;
  v_readiness := get_employee_readiness(v_onboarding_id);

  IF v_readiness = 'READY' THEN
    UPDATE employee_onboardings
    SET completed_at = now()
    WHERE id = v_onboarding_id AND completed_at IS NULL;
  ELSE
    -- If re-submitted after being complete, clear completed_at
    UPDATE employee_onboardings
    SET completed_at = NULL
    WHERE id = v_onboarding_id AND v_readiness != 'READY';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_check_onboarding_complete
  AFTER UPDATE ON step_submissions
  FOR EACH ROW
  WHEN (OLD.status IS DISTINCT FROM NEW.status)
  EXECUTE FUNCTION check_onboarding_complete();

-- ── Auto-seed template + steps when company is created ───
-- Called from API route (not a DB trigger) because we need
-- nanoid for the token — see src/lib/seed.ts

-- ── Dashboard overview function ───────────────────────────
-- Returns counts per readiness status for a company
CREATE OR REPLACE FUNCTION get_company_overview(p_company_id UUID)
RETURNS TABLE (
  readiness_status TEXT,
  employee_count   BIGINT
) AS $$
  SELECT
    get_employee_readiness(eo.id) AS readiness_status,
    COUNT(*) AS employee_count
  FROM employee_onboardings eo
  JOIN employees e ON e.id = eo.employee_id
  WHERE eo.company_id = p_company_id
    AND e.is_active = true
  GROUP BY get_employee_readiness(eo.id);
$$ LANGUAGE sql STABLE;

-- ── Get stale submissions for reminders ──────────────────
CREATE OR REPLACE FUNCTION get_stale_submissions(p_hours INT DEFAULT 48)
RETURNS TABLE (
  submission_id   UUID,
  employee_id     UUID,
  company_id      UUID,
  employee_name   TEXT,
  employee_phone  TEXT,
  step_title      TEXT,
  onboard_token   TEXT,
  reminder_count  INT
) AS $$
  SELECT
    ss.id,
    e.id,
    e.company_id,
    e.full_name,
    e.phone,
    ts.title,
    e.onboard_token,
    ss.reminder_count
  FROM step_submissions ss
  JOIN employees e ON e.id = ss.employee_id
  JOIN template_steps ts ON ts.id = ss.template_step_id
  WHERE ss.status IN ('NOT_STARTED', 'SUBMITTED')
    AND ss.reminder_count < 3
    AND e.is_active = true
    AND (
      ss.reminder_sent_at IS NULL
      OR ss.reminder_sent_at < now() - make_interval(hours => p_hours)
    )
  ORDER BY e.company_id, e.id, ts.sort_order;
$$ LANGUAGE sql STABLE;
