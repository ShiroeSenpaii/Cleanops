-- ============================================================
-- CleanOps — Migration 004: Seed Step Definitions
-- These are the 6 hardcoded steps used as a reference.
-- The API copies these into each company's template on signup.
-- ============================================================

-- We store step definitions in a reference table so the API
-- can seed new companies without hardcoding in TypeScript.

CREATE TABLE step_definitions (
  step_key       TEXT PRIMARY KEY,
  title          TEXT NOT NULL,
  title_es       TEXT NOT NULL,
  description    TEXT NOT NULL,
  description_es TEXT NOT NULL,
  step_type      TEXT NOT NULL,
  sort_order     INT NOT NULL
);

INSERT INTO step_definitions VALUES
(
  'sign_contract',
  'Sign Contract',
  'Firmar Contrato',
  'Upload a signed copy of your employment contract. You can sign it digitally or print, sign, and take a photo.',
  'Sube una copia firmada de tu contrato de trabajo. Puedes firmarlo digitalmente o imprimirlo, firmarlo y tomar una foto.',
  'document_upload',
  1
),
(
  'upload_photo_id',
  'Upload Photo ID',
  'Subir Identificación con Foto',
  'Take a clear photo of your government-issued ID (driver''s license, passport, or state ID). Make sure all four corners are visible.',
  'Toma una foto clara de tu identificación oficial (licencia de conducir, pasaporte o ID estatal). Asegúrate de que los cuatro rincones sean visibles.',
  'document_upload',
  2
),
(
  'fill_w9',
  'Complete W-9 Form',
  'Completar Formulario W-9',
  'Download, fill out, and upload your completed W-9 tax form. This is required for payment processing.',
  'Descarga, completa y sube tu formulario W-9 de impuestos. Esto es necesario para procesar tus pagos.',
  'document_upload',
  3
),
(
  'direct_deposit',
  'Direct Deposit Info',
  'Información de Depósito Directo',
  'Upload a voided check or bank letter showing your account and routing number for direct deposit payments.',
  'Sube un cheque anulado o carta bancaria que muestre tu número de cuenta y número de ruta para pagos por depósito directo.',
  'document_upload',
  4
),
(
  'coi_acknowledgment',
  'COI Acknowledgment',
  'Reconocimiento de Seguro',
  'Confirm that you have read and understand the company''s Certificate of Insurance policy.',
  'Confirma que has leído y comprendido la póliza del Certificado de Seguro de la empresa.',
  'acknowledgment',
  5
),
(
  'background_consent',
  'Background Check Consent',
  'Consentimiento de Verificación de Antecedentes',
  'Confirm your consent for a background check as required for employment.',
  'Confirma tu consentimiento para una verificación de antecedentes, requerida para el empleo.',
  'acknowledgment',
  6
);
