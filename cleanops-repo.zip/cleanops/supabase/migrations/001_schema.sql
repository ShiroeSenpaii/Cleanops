-- ============================================================
-- CleanOps — Migration 001: Core Schema
-- Run: supabase db push  (or paste into Supabase SQL editor)
-- ============================================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── companies ────────────────────────────────────────────
CREATE TABLE companies (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         TEXT NOT NULL,
  slug         TEXT UNIQUE NOT NULL,
  phone        TEXT,
  logo_url     TEXT,
  created_at   TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at   TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- ── owners ───────────────────────────────────────────────
CREATE TABLE owners (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  full_name    TEXT,
  email        TEXT NOT NULL,
  created_at   TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at   TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- ── employees ────────────────────────────────────────────
CREATE TABLE employees (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id         UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  full_name          TEXT NOT NULL,
  phone              TEXT,
  email              TEXT,
  preferred_language TEXT NOT NULL DEFAULT 'en' CHECK (preferred_language IN ('en', 'es')),
  is_available       BOOLEAN NOT NULL DEFAULT true,
  onboard_token      TEXT UNIQUE NOT NULL,
  token_expires_at   TIMESTAMPTZ,
  is_active          BOOLEAN NOT NULL DEFAULT true,
  notes              TEXT,
  created_at         TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at         TIMESTAMPTZ DEFAULT now() NOT NULL
);

CREATE INDEX idx_employees_onboard_token ON employees(onboard_token);
CREATE INDEX idx_employees_company_id    ON employees(company_id);

-- ── onboarding_templates ─────────────────────────────────
CREATE TABLE onboarding_templates (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name         TEXT NOT NULL DEFAULT 'Standard Onboarding',
  is_active    BOOLEAN NOT NULL DEFAULT true,
  created_at   TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at   TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- ── template_steps ───────────────────────────────────────
CREATE TABLE template_steps (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id     UUID NOT NULL REFERENCES onboarding_templates(id) ON DELETE CASCADE,
  step_key        TEXT NOT NULL,
  title           TEXT NOT NULL,
  title_es        TEXT NOT NULL DEFAULT '',
  description     TEXT NOT NULL DEFAULT '',
  description_es  TEXT NOT NULL DEFAULT '',
  video_gif_url   TEXT,
  step_type       TEXT NOT NULL CHECK (step_type IN ('document_upload', 'acknowledgment')),
  is_required     BOOLEAN NOT NULL DEFAULT true,
  sort_order      INT NOT NULL,
  created_at      TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- ── employee_onboardings ─────────────────────────────────
CREATE TABLE employee_onboardings (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id  UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  template_id  UUID NOT NULL REFERENCES onboarding_templates(id),
  company_id   UUID NOT NULL REFERENCES companies(id),
  started_at   TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at   TIMESTAMPTZ DEFAULT now() NOT NULL,
  UNIQUE(employee_id, template_id)
);

-- ── step_submissions ─────────────────────────────────────
CREATE TABLE step_submissions (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  onboarding_id     UUID NOT NULL REFERENCES employee_onboardings(id) ON DELETE CASCADE,
  template_step_id  UUID NOT NULL REFERENCES template_steps(id),
  company_id        UUID NOT NULL REFERENCES companies(id),
  employee_id       UUID NOT NULL REFERENCES employees(id),
  status            TEXT NOT NULL DEFAULT 'NOT_STARTED'
                    CHECK (status IN ('NOT_STARTED','SUBMITTED','NEEDS_REVIEW','APPROVED','REJECTED')),
  file_path         TEXT,
  file_name         TEXT,
  file_size_bytes   INT,
  mime_type         TEXT,
  notes_from_owner  TEXT,
  submitted_at      TIMESTAMPTZ,
  reviewed_at       TIMESTAMPTZ,
  reviewed_by       UUID REFERENCES owners(id),
  reminder_sent_at  TIMESTAMPTZ,
  reminder_count    INT NOT NULL DEFAULT 0,
  created_at        TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at        TIMESTAMPTZ DEFAULT now() NOT NULL,
  UNIQUE(onboarding_id, template_step_id)
);

CREATE INDEX idx_step_submissions_employee  ON step_submissions(employee_id);
CREATE INDEX idx_step_submissions_company   ON step_submissions(company_id);
CREATE INDEX idx_step_submissions_status    ON step_submissions(status);

-- ── message_logs ─────────────────────────────────────────
CREATE TABLE message_logs (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    UUID NOT NULL REFERENCES companies(id),
  employee_id   UUID NOT NULL REFERENCES employees(id),
  owner_id      UUID REFERENCES owners(id),
  channel       TEXT NOT NULL DEFAULT 'whatsapp'
                CHECK (channel IN ('whatsapp', 'sms', 'email')),
  message_type  TEXT NOT NULL
                CHECK (message_type IN ('onboarding_invite','reminder','approved','rejected')),
  link_url      TEXT NOT NULL,
  was_opened    BOOLEAN NOT NULL DEFAULT false,
  opened_at     TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- ── bulk_invites ─────────────────────────────────────────
CREATE TABLE bulk_invites (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    UUID NOT NULL REFERENCES companies(id),
  owner_id      UUID NOT NULL REFERENCES owners(id),
  filename      TEXT NOT NULL,
  total_rows    INT NOT NULL DEFAULT 0,
  success_count INT NOT NULL DEFAULT 0,
  error_count   INT NOT NULL DEFAULT 0,
  status        TEXT NOT NULL DEFAULT 'PENDING'
                CHECK (status IN ('PENDING','PROCESSING','DONE','FAILED')),
  error_log     JSONB,
  created_at    TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- ── auto-update updated_at ───────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_companies_updated_at
  BEFORE UPDATE ON companies
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_owners_updated_at
  BEFORE UPDATE ON owners
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_employees_updated_at
  BEFORE UPDATE ON employees
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_employee_onboardings_updated_at
  BEFORE UPDATE ON employee_onboardings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_step_submissions_updated_at
  BEFORE UPDATE ON step_submissions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
