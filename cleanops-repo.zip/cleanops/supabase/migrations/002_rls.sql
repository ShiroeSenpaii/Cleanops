-- ============================================================
-- CleanOps — Migration 002: Row-Level Security
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE companies           ENABLE ROW LEVEL SECURITY;
ALTER TABLE owners              ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees           ENABLE ROW LEVEL SECURITY;
ALTER TABLE onboarding_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE template_steps      ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_onboardings ENABLE ROW LEVEL SECURITY;
ALTER TABLE step_submissions    ENABLE ROW LEVEL SECURITY;
ALTER TABLE message_logs        ENABLE ROW LEVEL SECURITY;
ALTER TABLE bulk_invites        ENABLE ROW LEVEL SECURITY;

-- ── Helper: get company_id for the current auth user ─────
CREATE OR REPLACE FUNCTION get_my_company_id()
RETURNS UUID AS $$
  SELECT company_id FROM owners WHERE user_id = auth.uid()
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- ── companies ────────────────────────────────────────────
CREATE POLICY "owner_select_own_company"
  ON companies FOR SELECT
  USING (id = get_my_company_id());

CREATE POLICY "owner_update_own_company"
  ON companies FOR UPDATE
  USING (id = get_my_company_id());

-- ── owners ───────────────────────────────────────────────
CREATE POLICY "owner_select_self"
  ON owners FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "owner_update_self"
  ON owners FOR UPDATE
  USING (user_id = auth.uid());

-- ── employees ────────────────────────────────────────────
CREATE POLICY "owner_select_own_employees"
  ON employees FOR SELECT
  USING (company_id = get_my_company_id());

CREATE POLICY "owner_insert_own_employees"
  ON employees FOR INSERT
  WITH CHECK (company_id = get_my_company_id());

CREATE POLICY "owner_update_own_employees"
  ON employees FOR UPDATE
  USING (company_id = get_my_company_id());

CREATE POLICY "owner_delete_own_employees"
  ON employees FOR DELETE
  USING (company_id = get_my_company_id());

-- Employee portal: read own record by token (anon access via service role in API)
-- Token-based access is handled in API routes using the service role client,
-- so no anon policy needed here — keeps the token as the only gate.

-- ── onboarding_templates ─────────────────────────────────
CREATE POLICY "owner_select_own_templates"
  ON onboarding_templates FOR SELECT
  USING (company_id = get_my_company_id());

CREATE POLICY "owner_insert_own_templates"
  ON onboarding_templates FOR INSERT
  WITH CHECK (company_id = get_my_company_id());

-- ── template_steps ───────────────────────────────────────
CREATE POLICY "owner_select_own_steps"
  ON template_steps FOR SELECT
  USING (
    template_id IN (
      SELECT id FROM onboarding_templates WHERE company_id = get_my_company_id()
    )
  );

CREATE POLICY "owner_insert_own_steps"
  ON template_steps FOR INSERT
  WITH CHECK (
    template_id IN (
      SELECT id FROM onboarding_templates WHERE company_id = get_my_company_id()
    )
  );

-- ── employee_onboardings ─────────────────────────────────
CREATE POLICY "owner_select_own_onboardings"
  ON employee_onboardings FOR SELECT
  USING (company_id = get_my_company_id());

CREATE POLICY "owner_insert_own_onboardings"
  ON employee_onboardings FOR INSERT
  WITH CHECK (company_id = get_my_company_id());

CREATE POLICY "owner_update_own_onboardings"
  ON employee_onboardings FOR UPDATE
  USING (company_id = get_my_company_id());

-- ── step_submissions ─────────────────────────────────────
CREATE POLICY "owner_select_own_submissions"
  ON step_submissions FOR SELECT
  USING (company_id = get_my_company_id());

CREATE POLICY "owner_update_own_submissions"
  ON step_submissions FOR UPDATE
  USING (company_id = get_my_company_id());

CREATE POLICY "owner_insert_own_submissions"
  ON step_submissions FOR INSERT
  WITH CHECK (company_id = get_my_company_id());

-- ── message_logs ─────────────────────────────────────────
CREATE POLICY "owner_select_own_logs"
  ON message_logs FOR SELECT
  USING (company_id = get_my_company_id());

CREATE POLICY "owner_insert_own_logs"
  ON message_logs FOR INSERT
  WITH CHECK (company_id = get_my_company_id());

-- ── bulk_invites ─────────────────────────────────────────
CREATE POLICY "owner_select_own_bulk"
  ON bulk_invites FOR SELECT
  USING (company_id = get_my_company_id());

CREATE POLICY "owner_insert_own_bulk"
  ON bulk_invites FOR INSERT
  WITH CHECK (company_id = get_my_company_id());

-- ── Storage bucket policies ───────────────────────────────
-- Run this in Supabase dashboard > Storage > employee-documents > Policies
-- or via SQL after creating the bucket:
--
-- CREATE POLICY "owner_read_own_docs"
--   ON storage.objects FOR SELECT
--   USING (
--     bucket_id = 'employee-documents' AND
--     (storage.foldername(name))[1] = get_my_company_id()::text
--   );
--
-- CREATE POLICY "owner_delete_own_docs"
--   ON storage.objects FOR DELETE
--   USING (
--     bucket_id = 'employee-documents' AND
--     (storage.foldername(name))[1] = get_my_company_id()::text
--   );
